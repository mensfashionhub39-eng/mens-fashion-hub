Men's Fashion Hub - Admin Store
================================
WhatsApp order number configured: +91 9798687943

1. Upload index.html to the GitHub repository root.
2. Keep the file name exactly: index.html
3. GitHub Pages should publish from main / (root).
4. Open the Pages URL and use Shop Now / Store.
5. Admin panel is included, but its product data is stored only in that browser.

IMPORTANT:
GitHub Pages is static hosting. A secure shared admin panel, central product database,
customer order database, login system and payment processing need a separate backend
such as Firebase, Supabase, or an e-commerce platform. Do not put admin passwords
or private customer data into client-side JavaScript/localStorage.
